<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('admin_valid') == TRUE && $this->session->userdata('level') == " "){
			redirect("admin");
		}

		$this->load->view('login');
	}

	public function do_login()
	{
		$u = $this->input->post("user");
		$p = md5($this->input->post("pass"));

		// echo json_encode('user' => $user, 'pass' => $pass);
		// echo $u."<br>".$p;

 		$cari = $this->model_admin->cek_login($u, $p)->row();
		$hitung = $this->model_admin->cek_login($u, $p)->num_rows();

		if ($hitung > 0) {

			$data = array('admin_id' => $cari->id_user ,
							'admin_user' => $cari->username,
							'admin_nama' => $cari->nama,
							'level'=> $cari->level,
							'admin_valid' => TRUE
			);

			$this->session->set_userdata($data);

		if ($cari->level == 'admin') {
			redirect('admin','refresh');
		}
		elseif ($cari->level == 'user') {
			redirect('user');
		}
	}
		else{
		echo	$this->session->set_flashdata("k",'<div class="alert alert-danger text-center">Username or Password is Wrong</div>');
		redirect('login');
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		$this->session->unset_userdata('level');
		redirect('login');
	}
}
/* End of file login.php */
/* Location: ./application/controllers/login.php */

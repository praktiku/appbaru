<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct(){
		parent::__construct();
		// $this->load->helper(array('url','form'));
		// $this->load->model('model_admin');
	}

	function index(){
		if($this->session->userdata('admin_valid') != TRUE && $this->session->userdata('level') == ""){
			redirect("login");
		}
		$a['daya']	= $this->model_admin->tampil_daya()->num_rows();
		$a['jenis']	= $this->model_admin->tampil_jenis()->num_rows(); //untuk ambil data dari file model_admin.php dengan function tampil_jenis
		$a['surat_keluar']	= $this->model_admin->tampil_surat_keluar()->num_rows();
		$a['page']	= "home";

		$this->load->view('admin/index', $a);
	}

	/* Fungsi Jenis Surat */
	function jenis(){
		$a['data']	= $this->model_admin->tampil_jenis()->result_object();
		$a['page']	= "jenis";

		$this->load->view('admin/index', $a);
	}
	// Fungsi Daya
	function daya(){
		$a['data']	= $this->model_admin->tampil_daya()->result_object();
		$a['page']	= "daya";

		$this->load->view('admin/index', $a);
	}

	function tambah_jenis(){
		$a['page']	= "tambah_jenis";

		$this->load->view('admin/index', $a);
	}

	function insert_jenis(){

		$namajenis = $this->input->post('namajenis');
		$object = array(
				'namajenis' => $namajenis
			);
		$this->db->insert('tb_jenis', $object);

		redirect('admin/jenis','refresh');
	}
	// Fungsi Tambah daya
	function tambah_daya(){
		$a['page']	= "tambah_daya";

		$this->load->view('admin/index', $a);
	}

	function insert_daya(){

		$jenispln = $this->input->post('jenispln');
		$kwh = $this->input->post('kwh');
		$va = $this->input->post('va');
		$beban = $this->input->post('beban');
		$object = array(
				'jenispln' => $jenispln,
				'kwh' => $kwh,
				'beban' => $beban,
				'va' => $va
			);
		$this->db->insert('tb_daya', $object);

		redirect('admin/daya','refresh');
	}
//

	function edit_jenis($id){
		$a['editdata']	= $this->db->get_where('tb_jenis',array('id_jenis'=>$id))->result_object();
		$a['page']	= "edit_jenis";

		$this->load->view('admin/index', $a);
	}

	function update_jenis(){
		$id_jenis = $this->input->post('id_jenis');
		$namajenis = $this->input->post('namajenis');
		$object = array(
				'namajenis' => $namajenis
			);
		$this->db->where('id_jenis', $id_jenis);
		$this->db->update('tb_jenis', $object);

		redirect('admin/jenis','refresh');
	}
// edit daya
function edit_daya($id){
	$a['editdata']	= $this->db->get_where('tb_daya',array('id_daya'=>$id))->result_object();
	$a['page']	= "edit_daya";

	$this->load->view('admin/index', $a);
}

function update_daya(){
	$id_daya = $this->input->post('id_daya');
	$va = $this->input->post('va');
	$kwh = $this->input->post('kwh');
	$jenispln = $this->input->post('jenispln');
	$beban = $this->input->post('beban');
	$object = array(
			'va' => $va,
			'kwh' => $kwh,
			'jenispln' => $jenispln,
			'beban' => $beban
		);
	$this->db->where('id_daya', $id_daya);
	$this->db->update('tb_daya', $object);

	redirect('admin/daya','refresh');
}
//
	function hapus_jenis($id){

		$this->model_admin->hapus_jenis($id);
		redirect('admin/jenis','refresh');
	}
// fungsi Hapus
	function hapus_daya($id){

	$this->model_admin->hapus_daya($id);
	redirect('admin/daya','refresh');
}
	/* Fungsi Surat Keluar */
	function transaksi(){
		$a['data']	= $this->model_admin->tampil_surat_keluar()->result_object();
		$a['page']	= "transaksi";

		$this->load->view('admin/index', $a);
	}

	function tambah_transaksi(){
		$a['page']	= "tambah_transaksi";

		$this->load->view('admin/index', $a);
	}

	function insert_transaksi(){

		$jenis = $this->input->post('id_jenis');
		$no = $this->input->post('nopel');
		$tgl = $this->input->post('tgl');
		$nominal = $this->input->post('nominal');
		$notrans = $this->input->post('no_trans');
		$status = $this->input->post('status');
		$id_user = $this->input->post('id_user');
		$id_daya = $this->input->post('id_daya');
		$ket = $this->input->post('pemakaian');
		$object = array(
				'id_jenis' => $jenis,
				'nopel' => $no,
				'tgl' => $tgl,
				'nominal' => $nominal,
				'no_trans' => $notrans,
				'status' => $status,
				'id_user' => $id_user,
				'id_daya' => $id_daya,
				'pemakaian' => $ket
			);
		$this->db->insert('tb_transaksi', $object);

		redirect('admin/transaksi','refresh');
	}

	function edit_transaksi($id){
		$a['editdata']	= $this->db->get_where('tb_transaksi',array('id_trans'=>$id))->result_object();
		$a['page']	= "edit_transaksi";

		$this->load->view('admin/index', $a);
	}

	function update_transaksi(){
		$id = $this->input->post('id_trans');
		$jenis = $this->input->post('id_jenis');
		$nopel = $this->input->post('nopel');
		$tgl = $this->input->post('tgl');
		$nominal = $this->input->post('nominal');
		$status = $this->input->post('status');
		$id_daya = $this->input->post('id_daya');
		$ket = $this->input->post('pemakaian');
		$object = array(
				'id_jenis' => $jenis,
				'nopel' => $nopel,
				'tgl' => $tgl,
				'nominal' => $nominal,
				'status' => $status,
				'id_daya' => $id_daya,
				'pemakaian' => $ket
			);
		$this->db->where('id_trans', $id);
		$this->db->update('tb_transaksi', $object);

		redirect('admin/transaksi','refresh');
	}


	function hapus_transaksi($id){

		$this->model_admin->hapus_surat_keluar($id);
		redirect('admin/transaksi','refresh');
	}

	/* Fungsi Manage User */
	function manage_user(){
		$a['data']	= $this->model_admin->tampil_user()->result_object();
		$a['page']	= "manage_user";

		$this->load->view('admin/index', $a);
	}

	function tambah_user(){
		$a['page']	= "tambah_user";

		$this->load->view('admin/index', $a);
	}

	function insert_user(){

		$user 	  = $this->input->post('user');
		$password = $this->input->post('password');
		$nama	  = $this->input->post('nama');
		$level	  = $this->input->post('level');

		$object = array(
				'username' => $user,
				'password' => md5($password),
				'nama' => $nama,
				'level' =>$level
			);
		$this->model_admin->insert_user($object);

		redirect('admin/manage_user','refresh');
	}

	function edit_user($id){
		$a['editdata']	= $this->model_admin->edit_user($id)->result_object();
		$a['page']	= "edit_user";

		$this->load->view('admin/index', $a);
	}

	function update_user(){
		$id 	  = $this->input->post('id');
		$username 	  = $this->input->post('username');
		$password = $this->input->post('password');
		$pass_old = $this->input->post('pass_old');
		$nama	  = $this->input->post('nama');
		$level	  = $this->input->post('level');

		if (empty($password)) {
			$object = array(
				'username' => $username,
				'password' => $password,
				'nama' => $nama,
				'level' => $level
			);
		}else{
			$object = array(
				'username' => $username,
				'password' => $pass_old,
				'nama' => $nama
			);
		}


		$this->model_admin->update_user($id, $object);

		redirect('admin/manage_user','refresh');
	}

	function hapus_user($id){

		$this->model_admin->hapus_user($id);
		redirect('admin/manage_user','refresh');
	}

// Prabayar
function welcome(){

	$this->load->view('welcome_message');
}
//

//
function pembayaran(){
	$kobar=$this->input->post('kode_brg');
	$x['brg']=$this->model_admin->get_barang($kobar);
	$x['page']	= "pembayaran";
	$this->load->view('admin/index', $x);

}
// Pengetestan
function get_transaksi(){
	 $kobar=$this->input->post('kode_brg');
		$x['brg']=$this->model_admin->get_barang($kobar);
		$this->load->view('admin/v_detail_trans',$x);
}
function get_transaksi1(){
	 $kobar=$this->input->post('kode_brg');
		$x['brg']=$this->model_admin->get_barang($kobar);
		$this->load->view('admin/v_detail_trans1',$x);
}
//
function test10(){
	 $data['data']=$this->model_admin->tampil_barang();
		$this->load->view('admin/v_trans',$data);
}
function tampildata2(){
		$a = $this->model_admin->tampil_surat_keluar()->result_object();
	$this->load->view('admin/tampildata');
}
}

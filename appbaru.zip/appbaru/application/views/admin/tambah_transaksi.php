<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Tambah
              <small>Transaksi</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>admin/transaksi">Transaksi</a></li>
              <li class="active">Tambah</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Data Tambah Transaksi</h3>
              </div>
              <?php $a= 1;
              $b = $a++;
              ?>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('admin/insert_transaksi'); ?>
                <input type="hidden" name="no_trans" value="AP<?php echo date("mY");?>T<?php echo Date("s");?>">
                <input type="hidden" name="status" value="Dalam Proses">
                <input type="hidden" name="id_user" value="<?php echo $this->session->userdata('admin_id');?>">
                <div class="form-group">
                  <label for="exampleInputEmail1">No.Pelanggan</label>
                    <input type="text" class="form-control" name="nopel" placeholder="Contoh : 102030405060"/>
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Tanggal</label>
                    <input type="text" class="form-control" name="tgl" id="tgl_surat" data-date-format="yyyy-mm-dd" placeholder="Tanggal"/>
                </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">Nama Jenis</label>
                      <select name="id_jenis" class="form-control">
                        <?php
                        $jenis = $this->db->query("SELECT * FROM tb_jenis")->result();
                        foreach ($jenis as $l_surat) {
                          echo "<option  value='$l_surat->id_jenis'>".ucwords($l_surat->namajenis)."</option>";
                        }
                        ?>

                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">harga/kwh</label>
                      <select id="kwh" class="form-control">
                        <?php

                        $jenis = $this->db->query("SELECT * FROM tb_daya")->result();

                        foreach ($jenis as $l_surat) {
                          echo "<option value='$l_surat->kwh;'>Rp.".($l_surat->kwh). "</option>";
                      }
                        ?>

                      </select>

                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Usage</label>
                      <input type="text" class="form-control" name="pemakaian" id="us" placeholder="Usage"/>
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">Tengangan</label>
                      <select name="id_daya" class="form-control">
                        <?php

                        $jenis = $this->db->query("SELECT * FROM tb_daya")->result();

                        foreach ($jenis as $l_surat) {
                          echo "-<option value='$l_surat->id_daya;'>" .($l_surat->jenispln)."-".($l_surat->va). " VA</option>";
                      }
                        ?>

                      </select>

                  </div>
                  <!-- <div class="hitung"> -->

                  <div class="form-group">
                    <label for="exampleInputEmail1">Nominal</label>
                      <input type="text" class="form-control" name="nominal" id="hasil" placeholder="Nominal"/>

                  </div>
                  <!-- Jquery Untuk Menghitung Secara Real Time Untuk Total semua -->
                  <script type="text/javascript" src="<?php echo base_url()?>assets\bootstrap\js\jquery-3.3.1.js"></script>

                   <script type="text/javascript">
                   $(document).ready(function(){
                total();
                $('#kwh').change(function() {
                    total();
                });
                $('#hasil').change(function() {
                    total();
                });
            });
                     $(document).ready(function(){
                       $("#us").keyup(function(){
                         var harga  = parseInt($("#kwh").val());
                         var diskon  = parseInt($("#us").val());
                         var total = harga * diskon;
                         $("#hasil").val(total);
                       });
                     });
                   </script>
                <!-- </div> -->
                  <!-- Sampai INI ----- -->
                  <a href="<?php echo base_url(); ?>admin/transaksi" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php echo form_close(); ?>

              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
        </div>
      </div>

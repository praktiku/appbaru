<!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
          <section class="content-header">
            <h1>
              Edit
              <small>Transaksi</small>
            </h1>
            <ol class="breadcrumb">
              <li><i class="fa fa-dashboard"></i> Home</a></li>
              <li><a href="<?php echo base_url(); ?>admin/surat_keluar">Transaksi</a></li>
              <li class="active">Edit</li>
              <!--
              <li><a href="#">Layout</a></li>
              <li class="active">Top Navigation</li>
              -->
            </ol>
          </section>

          <!-- Main content -->
          <section class="content">
            <div class="box box-info">
              <div class="box-header with-border">
                <h3 class="box-title">Form Data Edit Transaksi</h3>
              </div>
              <div class="box-body">
                <!-- form start -->
                <?php echo form_open('admin/update_transaksi'); ?>
                <?php
                foreach ($editdata as $data):
                ?>
                <div class="form-group">
                  <label for="exampleInputEmail1">No.Pelanggan</label>
                    <input type="text" class="form-control" name="nopel" value="<?php echo $data->nopel ?>" />
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Tanggal</label>
                    <input type="text" class="form-control" name="tgl" id="tgl_surat" data-date-format="yyyy-mm-dd" value="<?php echo $data->tgl?>"/>
                </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jenis</label>
                      <select name="id_jenis" class="form-control">
                        <?php
                        $l_jenis = $this->db->query("SELECT * FROM tb_jenis")->result();

                        if (empty($l_jenis)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($l_jenis as $l_jenis_surat){
                        ?>
                       <option <?php if( $data->id_jenis == $l_jenis_surat->id_jenis) {echo "selected"; } ?> value='<?php echo $l_jenis_surat->id_jenis ;?>'><?php echo $l_jenis_surat->namajenis ;?></option>

                        <?php
                          }
                          }
                        ?>

                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Status</label>
                      <select name="status" class="form-control">
                       <option <?php if( $data->status == "Dalam Proses") {echo "selected"; } ?> value="Dalam Proses">Dalam Proses</option>
                       <option <?php if( $data->status == "Sudah Konfirmasi") {echo "selected"; } ?> value="Sudah Konfirmasi">Sudah Konfirmasi</option>
                      </select>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Jenis PLN</label>
                      <select name="id_daya" class="form-control">
                        <?php
                        $l_jenis = $this->db->query("SELECT * FROM tb_daya")->result();

                        if (empty($l_jenis)) {
                          echo "<option  value=''> --Tidak Ada Data-- </option>";
                        } else {
                        foreach($l_jenis as $l_jenis_surat){
                        ?>
                       <option <?php if( $data->id_daya == $l_jenis_surat->id_daya) {echo "selected"; } ?> value='<?php echo $l_jenis_surat->id_daya ;?>'><?php echo $l_jenis_surat->jenispln."-".($l_jenis_surat->va);?> VA</option>
                        <?php

                          }
                          }
                        ?>

                      </select>
                      <div class="form-group">
                        <label for="exampleInputEmail1">harga/kwh</label>
                          <select id="kwh" class="form-control">
                            <?php
                            $jenis = $this->db->query("SELECT * FROM tb_daya")->result();

                            foreach ($jenis as $l_surat) {
                              echo "<option value='$l_surat->kwh;'>Rp.".($l_surat->kwh). "</option>";
                          }?>

                          </select>

                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Usage</label>
                        <input type="text" name="pemakaian" class="form-control" id="us" value="<?php echo $data->pemakaian ?>" >
                      </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">Nominal</label>
                      <input type="text" class="form-control" name="nominal" id="hasil" value="<?php echo $data->nominal?>"/>
                  </div>

                  <input type="hidden" name="id_trans" value="<?php echo $data->id_trans ?>">
                  <a href="<?php echo base_url(); ?>admin/transaksi" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Batal</a>
                  <button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i> Simpan</button>
                <?php endforeach ?>
                <?php echo form_close(); ?>
              </div><!-- /.box-body -->
            </div><!-- /.box -->
          </section><!-- /.content -->
          <script type="text/javascript" src="<?php echo base_url()?>assets\bootstrap\js\jquery-3.3.1.js"></script>

           <script type="text/javascript">
           $(document).ready(function(){
        total();
        $('#kwh').change(function() {
            total();
        });
        $('#hasil').change(function() {
            total();
        });
    });
             $(document).ready(function(){
               $("#us").keyup(function(){
                 var harga  = parseInt($("#kwh").val());
                 var diskon  = parseInt($("#us").val());
                 var total = harga * diskon;
                 $("#hasil").val(total);
               });
             });
           </script>

        </div>

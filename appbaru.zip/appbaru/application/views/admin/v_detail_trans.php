				<?php 
					error_reporting(0);
					$b=$brg->row_array();
				?>
				
		<form action="" method="post">
<td><p>Tanggal : <?php echo tgl_indo($b['tgl'])?></p>
	<button type="submit" class="btn btn-sm btn-primary">Bayar</button></td>
<div class="row">
	<div class="col-sm-12">
<td>
	Nama :
	<input type="text" name="nopel" value="<?php echo $b['nama'];?>" class="form-control" readonly>
</td>
<td>
	Jenis :
	<input type="text" name="jenispln" value="<?php echo $b['namajenis'];?>" class="form-control" readonly>
</td>
<td>
	Status :
	<input type="text" name="va" value="<?php echo $b['status'];?> "  class="form-control" readonly>
</td>
<td>
	Pemakaian :
	<input type="text" name="pemakaian" value="<?php echo $b['pemakaian'];?> Kwh"  class="form-control" readonly>
</td>
<td>
	Total :
	<input type="text" name="nominal" value="Rp.<?php echo number_format($b['nominal'],0,'.','.');?>"  class="form-control" readonly>
</td>
	</div>
</div>
		
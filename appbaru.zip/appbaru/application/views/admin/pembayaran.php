    <!-- Content Wrapper. Contains page content -->
          <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content">
              <!-- Small boxes (Stat box) -->
              <div class="row">
                <div class="col-lg-3 col-xs-6">
                    <div>
    <h2>Pembayaran</h2>
      <ul class="nav nav-tabs">
        <li class="active"><a href="#home">Pascabayar</a></li>
        <li><a href="#menu1">Prabayar</a></li>
      </ul>
      <div class="tab-content form-group">
         <div id="home" class="tab-pane fade in active">
                        <h4>Pembayaran Pascabayar</h4>
                        <h5>Nomor Pelanggan</h5>
                        <input type="text" name="kode_brg" id="kode_brg" class="form-control" placeholder="MAX-16" max="16">                     
                        <div id="detail_barang" style="position:absolute;">
                        </div>
                        </div>
         <div id="menu1" class="tab-pane fade">
            <h4>Pembayaran Prabayar</h4>
          <h5>Nomor Pelanggan</h5>
                        <input type="text" name="kode_brg1" id="kode_brg1" class="form-control">
      <label for="exampleFormControlSelect1">Nominal</label>
      <select class="form-control">
        <option value="50000">Rp.50.000</option>
        <option value="100000">Rp.100.000</option>
        <option value="150000">Rp.150.000</option>
        <option value="200000">Rp.200.000</option>
        <option value="500000">Rp.500.000</option>
      </select>
    </div>
                        <div id="detail_barang1" style="position:absolute;">
                        </div>
                       
        </div>
           </div> <!-- /.row -->
            </div>
                  </div><!-- ./col -->
              </div><!-- /.row -->
            </section>
          </div>
           </form>
            
    
            <!-- ============ MODAL HAPUS =============== -->
            
    
            <!--END MODAL-->
    
            <!-- Footer -->
            
    
        <!-- /.container -->
    
        <!-- jQuery -->
        <script src="https://code.jquery.com/jquery-3.4.0.min.js"></script>
    
        <!-- Bootstrap Core JavaScript -->
        <!--<script src="<?php echo base_url().'assets/dist/js/bootstrap-select.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/bootstrap.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/dataTables.bootstrap.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/jquery.dataTables.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/jquery.price_format.min.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/moment.js'?>"></script>
        <script src="<?php echo base_url().'assets/js/bootstrap-datetimepicker.min.js'?>"></script>-->
         <script type="text/javascript" src="<?php echo base_url()?>assets\bootstrap\js\jquery-3.3.1.js"></script>
    
        
        
        <script type="text/javascript">
            $(document).ready(function(){
                //Ajax kabupaten/kota insert
                $("#kode_brg").focus();
                $("#kode_brg").on("input",function(){
                    var kobar = {kode_brg:$(this).val()};
                       $.ajax({
                   type: "POST",
                   url : "<?php echo base_url().'admin/get_transaksi';?>",
                   data: kobar,
                   success: function(msg){
                   $('#detail_barang').html(msg);
                   }
                });
                }); 
    
               
            });
        </script>
         </script>
        <script type="text/javascript">
            $(document).keyup(function(){
                //Ajax kabupaten/kota insert
                $("#kode_brg1").focus();
                $("#kode_brg1").on("input",function(){
                    var kobar2 = {kode_brg:$(this).val()};
                       $.ajax({
                   type: "POST",
                   url : "<?php echo base_url().'admin/get_transaksi1';?>",
                   data: kobar2,
                   success: function(msg){
                   $('#detail_barang1').html(msg);
                   }
                });
                }); 
    
               
            });
        </script>
        <script>
    $(document).ready(function(){
      $(".nav-tabs a").click(function(){
        $(this).tab('show');
      });
    });
        </script>
        
        
    </body>
    
    </html>

<table>
                <tr>
                    <th>Kode Barang</th>
                </tr>
                <tr>
                    <th><input type="text" name="nopel" id="nopel" class="form-control input-sm"></th>
                </tr>
                    <div id="detail_barang" style="position:absolute;">
                    </div>
            </table>
            <script type="text/javascript" src="<?php echo base_url()?>assets\bootstrap\js\jquery-3.3.1.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    //Ajax kabupaten/kota insert
    $("#nopel").focus();
    $("#nopel").keyup(function(){
        var kobar = {nopel:$(this).val()};
           $.ajax({
       type: "GET",
       url : "<?php echo base_url().'admin/get_transaksi';?>",
       data: kobar,
       success: function(msg){
       $('#detail_barang').html(msg);
       }
    });
    });

    $("#kode_brg").keypress(function(e){
        if(e.which==13){
            $("#jumlah").focus();
        }
    });
});
    </script>

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Model_admin extends CI_Model {


	public function tampil_jenis()
	{
		return $this->db->get('tb_jenis');
	}
	public function tampil_daya()
	{
		return $this->db->get('tb_daya');
	}

	public function tampil_surat_keluar()
	{
		return $this->db->query("SELECT a.*, b.id_jenis, b.namajenis, c.id_user, c.nama, d.id_daya, d.jenispln, d.va, d.kwh FROM tb_transaksi as a, tb_jenis as b, login as c, tb_daya as d WHERE a.id_jenis=b.id_jenis AND a.id_user=c.id_user AND a.id_daya=d.id_daya");
	}
/*
	public function edit_jenis($id)
	{
		return $this->db->get_where('tb_jenis_surat',array('jenis_id'=>$id));
	}
*/
	public function hapus_jenis($id)
	{
		return $this->db->delete('tb_jenis', array('id_jenis' => $id));
	}
	//hapus daya
	public function hapus_daya($id)
	{
		return $this->db->delete('tb_daya', array('id_daya' => $id));
	}
	//
	public function hapus_surat_keluar($id)
	{
		return $this->db->delete('tb_transaksi', array('id_trans' => $id));
	}

	public function cek_login($user, $pass)
	{
		$array = array('username' => $user, 'password' => $pass);

		$query = $this->db->where($array);

		$query = $this->db->get('login');

		return $query;
	}

	public function tampil_user()
	{
		return $this->db->get('login');
	}

	public function insert_user($object)
	{
		$this->db->insert('login', $object);
	}

	public function edit_user($id)
	{
		return $this->db->get_where('login',array('id_user'=>$id));
	}

	public function update_user($id, $object)
	{
		$this->db->where('id_user', $id);
		$this->db->update('login', $object);
	}

	public function hapus_user($id)
	{
		return $this->db->delete('login', array('id_user' => $id));
	}
	//AJAX UNTUK PEMBAYARAN
	function tampil_barang(){
		$hs=$this->db->query("SELECT a.*, b.id_jenis, b.namajenis, c.id_user, c.nama, d.id_daya, d.jenispln, d.va, d.kwh FROM tb_transaksi as a, tb_jenis as b, login as c, tb_daya as d WHERE a.id_jenis=b.id_jenis AND a.id_user=c.id_user AND a.id_daya=d.id_daya");
		return $hs;
	}
//AJAX TAMPILKAN
	function get_barang($kobar){
		$hsl=$this->db->query("SELECT a.*, b.id_jenis, b.namajenis, c.id_user, c.nama, d.id_daya, d.jenispln, d.va, d.kwh FROM tb_transaksi as a, tb_jenis as b, login as c, tb_daya as d WHERE a.id_jenis=b.id_jenis AND a.id_user=c.id_user AND a.id_daya=d.id_daya AND nopel='$kobar'");
		return $hsl;
	}

//	function get_kobar(){
//		$q = $this->db->query("SELECT MAX(RIGHT(barang_id,6)) AS kd_max FROM tbl_barang");
//        $kd = "";
//        if($q->num_rows()>0){
//            foreach($q->result() as $k){
//                $tmp = ((int)$k->kd_max)+1;
//                $kd = sprintf("%06s", $tmp);
//            }
//        }else{
//            $kd = "000001";
//        }
//        return "BR".$kd;
//	}
//}
}

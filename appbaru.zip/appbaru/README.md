# app_surat
App Surat Keluar 
Dibuat dengan : 
<ul>
<li>Codeigniter</li>
<li>Bootstrap Admin LTE</li>
<li>Javascript</li>
</ul>
 
Cara menggunakan : 
<ul>
<li>Ganti url lokasi folder CI nya. Buka file config, edit base_url() sesuai dengan lokasi tempat kalian menyimpan file2 CI nya.</li>
<li>Ganti settingan database, dan sesuaikan dengan settingan punya kalian</li>
</ul>

<br/>
<b>Update :</b>
<br/>
20181126
<br/>
1. Fix error

<br/><br/>
Link Demo
<br/>
http://demo.surdaysoft.com/surat

